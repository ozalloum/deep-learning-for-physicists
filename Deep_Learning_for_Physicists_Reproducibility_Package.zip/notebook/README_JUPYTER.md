# Jupyter notebook

Open `Deep_Learning_for_Physicists_Jupyter_Notebook.ipynb` in Jupyter.

1. Unpack `Deep_Learning_for_Physicists_Reproducibility.zip` and open the notebook from the package directory.
2. Leave `FULL_RETRAIN = False` for the fast frozen-data audit.
3. Set `FULL_RETRAIN = True` to rerun the neural-network experiments and regenerate the results.
4. The final cell creates a compact audit archive in the package directory.

The notebook discovers the extracted package rather than relying on an author's local filesystem path. If it is opened outside the unpacked package, set `PACKAGE_ZIP` in the first code cell to the local ZIP path.

