from pathlib import Path
import csv, json, time, platform, sys
import numpy as np
import pandas as pd
import torch
import matplotlib.pyplot as plt
from scipy.interpolate import RBFInterpolator
from scipy.integrate import solve_ivp

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'; FIG=ROOT/'manuscript'/'figures'; PLOTS=ROOT/'plots'
FIG.mkdir(parents=True,exist_ok=True); PLOTS.mkdir(parents=True,exist_ok=True)

def osc(t,w,z):
    t=np.asarray(t,float); disc=np.maximum(1-z*z,1e-12); wd=w*np.sqrt(disc)
    return np.exp(-z*w*t)*(np.cos(wd*t)+z/np.sqrt(disc)*np.sin(wd*t))

def rhs(t,s,w,z):
    x,v=s; return [v,-2*z*w*v-w*w*x]

def direct(w,z,t):
    sol=solve_ivp(rhs,(float(t[0]),float(t[-1])),[1.0,0.0],t_eval=np.asarray(t,float),args=(w,z),rtol=1e-10,atol=1e-12,method='DOP853')
    return sol.y[0]

tr=pd.read_csv(DATA/'oscillator_training_data.csv')
va=pd.read_csv(DATA/'oscillator_validation_data.csv')
gen=pd.read_csv(DATA/'generalization_predictions.csv')
X=tr[['t','omega0','zeta']].to_numpy(float); y=tr['x'].to_numpy(float)
Xv=va[['t','omega0','zeta']].to_numpy(float); yv=va['x'].to_numpy(float)
lo=np.array([0.,0.8,0.03]); hi=np.array([10.,2.,0.35])
Xs=(X-lo)/(hi-lo); Xvs=(Xv-lo)/(hi-lo)

t0=time.perf_counter()
rbf=RBFInterpolator(Xs,y,neighbors=64,kernel='gaussian',epsilon=3.0,smoothing=1e-5,degree=0)
rbf_build=time.perf_counter()-t0
t0=time.perf_counter(); rbf_val=rbf(Xvs); rbf_eval=time.perf_counter()-t0
rbf_val_mse=float(np.mean((rbf_val-yv)**2))
rows=[]
for (reg,cid),g in gen.groupby(['regime','case_id']):
    Xin=g[['t','omega0','zeta']].to_numpy(float); truth=g['x_exact'].to_numpy(float)
    pred=rbf((Xin-lo)/(hi-lo)); rel=float(np.linalg.norm(pred-truth)/np.linalg.norm(truth))
    rows.append((reg,cid,float(g['omega0'].iloc[0]),float(g['zeta'].iloc[0]),rel))
with open(DATA/'rbf_generalization_summary.csv','w',newline='') as f:
    w=csv.writer(f); w.writerow(['regime','case_id','omega0','zeta','relative_l2_error']); w.writerows(rows)
rbf_interp=float(np.mean([r[-1] for r in rows if r[0]=='interpolation']))
rbf_extra=float(np.mean([r[-1] for r in rows if r[0]=='extrapolation']))

# direct solver timings on 60 training systems using 301 points
params=tr[['trajectory_id','omega0','zeta']].drop_duplicates().head(60)
tt=np.linspace(0,10,301)
t0=time.perf_counter(); errs=[]
for _,r in params.iterrows():
    pred=direct(float(r.omega0),float(r.zeta),tt); truth=osc(tt,float(r.omega0),float(r.zeta)); errs.append(np.linalg.norm(pred-truth)/np.linalg.norm(truth))
solver_total=time.perf_counter()-t0; solver_per=solver_total/len(params); solver_rel=float(np.mean(errs))

# load trained neural model architecture for timing only
from torch import nn
class MLP(nn.Module):
    def __init__(self,width=48,depth=3):
        super().__init__(); layers=[nn.Linear(3,width),nn.Tanh()]
        for _ in range(depth-1): layers += [nn.Linear(width,width),nn.Tanh()]
        layers += [nn.Linear(width,1)]; self.net=nn.Sequential(*layers)
    def forward(self,x):
        lo_t=torch.tensor([0.0,0.8,0.03],dtype=x.dtype,device=x.device); hi_t=torch.tensor([10.0,2.0,0.35],dtype=x.dtype,device=x.device)
        return self.net(2.0*(x-lo_t)/(hi_t-lo_t)-1.0)
model=MLP(); model.load_state_dict(torch.load(DATA/'oscillator_surrogate.pt',map_location='cpu')); model.eval()
t0=time.perf_counter()
with torch.no_grad():
    for _,r in params.iterrows():
        xin=np.c_[tt,np.full_like(tt,float(r.omega0)),np.full_like(tt,float(r.zeta))].astype('float32')
        _=model(torch.from_numpy(xin))
net_total=time.perf_counter()-t0; net_per=net_total/len(params)

# update summary
summary=json.loads((DATA/'benchmark_summary.json').read_text())
summary.update({
 'rbf_validation_mse':rbf_val_mse,
 'rbf_mean_interpolation_relative_l2':rbf_interp,
 'rbf_mean_extrapolation_relative_l2':rbf_extra,
 'rbf_build_seconds':rbf_build,
 'rbf_validation_seconds':rbf_eval,
 'direct_solver_mean_relative_l2':solver_rel,
 'direct_solver_seconds_per_trajectory':solver_per,
 'network_seconds_per_trajectory':net_per,
})
(DATA/'benchmark_summary.json').write_text(json.dumps(summary,indent=2))
with open(DATA/'benchmark_summary.csv','w',newline='') as f:
    w=csv.writer(f); w.writerow(['metric','value']); w.writerows(summary.items())
with open(DATA/'baseline_comparison.csv','w',newline='') as f:
    w=csv.writer(f); w.writerow(['method','quantity','value'])
    w.writerows([
        ['neural_surrogate','trajectory_validation_mse',summary['trajectory_validation_mse']],
        ['rbf_interpolant','trajectory_validation_mse',rbf_val_mse],
        ['neural_surrogate','mean_interpolation_relative_l2',summary['mean_interpolation_relative_l2']],
        ['rbf_interpolant','mean_interpolation_relative_l2',rbf_interp],
        ['neural_surrogate','mean_extrapolation_relative_l2',summary['mean_extrapolation_relative_l2']],
        ['rbf_interpolant','mean_extrapolation_relative_l2',rbf_extra],
        ['direct_ode_solver','mean_relative_l2',solver_rel],
        ['direct_ode_solver','seconds_per_trajectory',solver_per],
        ['neural_surrogate','seconds_per_trajectory',net_per],
        ['neural_surrogate','training_seconds',summary['trajectory_model_training_seconds']],
        ['rbf_interpolant','build_seconds',rbf_build],
    ])

macro=f'''% Auto-generated benchmark values\n\\newcommand{{\\TrainMSE}}{{{summary['train_mse']:.3e}}}\n\\newcommand{{\\TrajectoryValMSE}}{{{summary['trajectory_validation_mse']:.3e}}}\n\\newcommand{{\\RandomPointMSE}}{{{summary['random_point_validation_mse']:.3e}}}\n\\newcommand{{\\RandomUnseenMSE}}{{{summary['random_split_unseen_trajectory_mse']:.3e}}}\n\\newcommand{{\\InterpRel}}{{{summary['mean_interpolation_relative_l2']:.3f}}}\n\\newcommand{{\\ExtraRel}}{{{summary['mean_extrapolation_relative_l2']:.3f}}}\n\\newcommand{{\\RBFValMSE}}{{{rbf_val_mse:.3e}}}\n\\newcommand{{\\RBFInterpRel}}{{{rbf_interp:.3f}}}\n\\newcommand{{\\RBFExtraRel}}{{{rbf_extra:.3f}}}\n\\newcommand{{\\SolverRel}}{{{solver_rel:.2e}}}\n\\newcommand{{\\SolverMs}}{{{solver_per*1e3:.2f}}}\n\\newcommand{{\\NetworkMs}}{{{net_per*1e3:.2f}}}\n\\newcommand{{\\TrainSeconds}}{{{summary['trajectory_model_training_seconds']:.1f}}}\n\\newcommand{{\\TrueOmega}}{{{summary['true_omega0']:.2f}}}\n\\newcommand{{\\EstOmega}}{{{summary['estimated_omega0']:.4f}}}\n\\newcommand{{\\TrueZeta}}{{{summary['true_zeta']:.2f}}}\n\\newcommand{{\\EstZeta}}{{{summary['estimated_zeta']:.4f}}}\n'''
(ROOT/'manuscript'/'benchmark_macros.tex').write_text(macro)
(ROOT/'supplementary'/'benchmark_macros.tex').write_text(macro)

plt.rcParams.update({'font.size':8.5,'axes.labelsize':8.5,'xtick.labelsize':7.5,'ytick.labelsize':7.5,'axes.spines.top':False,'axes.spines.right':False})
def panel_label(ax, label):
    ax.text(-0.12, 1.04, label, transform=ax.transAxes, ha='left', va='bottom', fontweight='bold', clip_on=False)

fig,axs=plt.subplots(1,2,figsize=(7.0,2.45))
x=np.arange(2); width=0.34
axs[0].bar(x-width/2,[summary['mean_interpolation_relative_l2'],summary['mean_extrapolation_relative_l2']],width,label='neural surrogate')
axs[0].bar(x+width/2,[rbf_interp,rbf_extra],width,label='local RBF')
axs[0].set_yscale('log'); axs[0].set_xticks(x,['interpolation','extrapolation']); axs[0].set_ylabel(r'mean relative $L^2$ error'); axs[0].legend(frameon=False,fontsize=7); panel_label(axs[0], '(a)')
axs[1].bar(np.arange(2),[solver_per*1e3,net_per*1e3]); axs[1].set_yscale('log'); axs[1].set_xticks([0,1],['direct ODE\nsolver','neural\nevaluation']); axs[1].set_ylabel('milliseconds per trajectory'); panel_label(axs[1], '(b)')
fig.tight_layout()
for out in [FIG/'baseline_comparison.pdf',PLOTS/'baseline_comparison.png']:
    fig.savefig(out,dpi=240,bbox_inches='tight')
plt.close(fig)
print(json.dumps({k:summary[k] for k in ['rbf_validation_mse','rbf_mean_interpolation_relative_l2','rbf_mean_extrapolation_relative_l2','direct_solver_mean_relative_l2','direct_solver_seconds_per_trajectory','network_seconds_per_trajectory']},indent=2))
