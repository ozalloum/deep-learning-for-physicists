#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import math
import platform
import random
import sys
import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
from scipy.integrate import solve_ivp
from scipy.interpolate import RBFInterpolator
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch
from torch import nn

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
FIG = ROOT / "manuscript" / "figures"
PLOTS = ROOT / "plots"
for d in (DATA, FIG, PLOTS):
    d.mkdir(parents=True, exist_ok=True)

SEED = 17
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
try:
    torch.use_deterministic_algorithms(True)
except Exception:
    pass

plt.rcParams.update(
    {
        "font.size": 8.6,
        "axes.labelsize": 8.6,
        "axes.titlesize": 8.8,
        "xtick.labelsize": 7.5,
        "ytick.labelsize": 7.5,
        "legend.fontsize": 7.2,
        "figure.dpi": 170,
        "savefig.bbox": "tight",
        "axes.spines.top": False,
        "axes.spines.right": False,
    }
)


def save(fig, name):
    fig.savefig(FIG / f"{name}.pdf")
    fig.savefig(PLOTS / f"{name}.png", dpi=240)
    plt.close(fig)


def panel_label(ax, label):
    """Place a panel label in the upper-left margin, outside the plotting area."""
    ax.text(
        -0.12,
        1.04,
        label,
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontweight="bold",
        clip_on=False,
    )


def csvwrite(path, header, rows):
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(rows)


def oscillator(t, omega0, zeta):
    t = np.asarray(t, dtype=float)
    disc = np.maximum(1.0 - zeta * zeta, 1e-12)
    wd = omega0 * np.sqrt(disc)
    return np.exp(-zeta * omega0 * t) * (
        np.cos(wd * t) + zeta / np.sqrt(disc) * np.sin(wd * t)
    )


def make_data(nparam, ntime, seed):
    rng = np.random.default_rng(seed)
    t = np.linspace(0.0, 10.0, ntime)
    X, y, ids, params = [], [], [], []
    for i in range(nparam):
        omega0 = rng.uniform(0.8, 2.0)
        zeta = rng.uniform(0.03, 0.35)
        yy = oscillator(t, omega0, zeta)
        X.append(np.c_[t, np.full_like(t, omega0), np.full_like(t, zeta)])
        y.append(yy[:, None])
        ids.extend([i] * ntime)
        params.append((i, omega0, zeta))
    return (
        np.vstack(X).astype("float32"),
        np.vstack(y).astype("float32"),
        np.asarray(ids),
        params,
    )


class MLP(nn.Module):
    def __init__(self, width=48, depth=3):
        super().__init__()
        layers = [nn.Linear(3, width), nn.Tanh()]
        for _ in range(depth - 1):
            layers += [nn.Linear(width, width), nn.Tanh()]
        layers += [nn.Linear(width, 1)]
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        lo = torch.tensor([0.0, 0.8, 0.03], dtype=x.dtype, device=x.device)
        hi = torch.tensor([10.0, 2.0, 0.35], dtype=x.dtype, device=x.device)
        return self.net(2.0 * (x - lo) / (hi - lo) - 1.0)


def train_model(X, y, Xv, yv, epochs=300, seed=SEED):
    torch.manual_seed(seed)
    model = MLP()
    opt = torch.optim.Adam(model.parameters(), lr=2e-3)
    mse = nn.MSELoss()
    Xt, yt = torch.from_numpy(X), torch.from_numpy(y)
    Xvt, yvt = torch.from_numpy(Xv), torch.from_numpy(yv)
    hist = []
    t0 = time.perf_counter()
    for ep in range(epochs):
        perm = torch.randperm(len(Xt))
        total = 0.0
        model.train()
        for i in range(0, len(Xt), 256):
            q = perm[i : i + 256]
            loss = mse(model(Xt[q]), yt[q])
            opt.zero_grad()
            loss.backward()
            opt.step()
            total += loss.item() * len(q)
        model.eval()
        with torch.no_grad():
            vloss = mse(model(Xvt), yvt).item()
        hist.append((ep + 1, total / len(Xt), vloss))
    return model, hist, time.perf_counter() - t0


# -----------------------------------------------------------------------------
# 1. Trajectory-level training and validation
# -----------------------------------------------------------------------------
X, y, ids, train_params = make_data(60, 60, SEED)
Xv, yv, idv, val_params = make_data(15, 60, SEED + 1)

csvwrite(
    DATA / "oscillator_training_data.csv",
    ["trajectory_id", "t", "omega0", "zeta", "x"],
    zip(ids, X[:, 0], X[:, 1], X[:, 2], y[:, 0]),
)
csvwrite(
    DATA / "oscillator_validation_data.csv",
    ["trajectory_id", "t", "omega0", "zeta", "x"],
    zip(idv, Xv[:, 0], Xv[:, 1], Xv[:, 2], yv[:, 0]),
)
csvwrite(
    DATA / "trajectory_parameter_split.csv",
    ["split", "trajectory_id", "omega0", "zeta"],
    [("train", i, w, z) for i, w, z in train_params]
    + [("validation", i, w, z) for i, w, z in val_params],
)

model, history, train_seconds = train_model(X, y, Xv, yv, epochs=300, seed=SEED)
torch.save(model.state_dict(), DATA / "oscillator_surrogate.pt")
csvwrite(DATA / "training_history.csv", ["epoch", "train_mse", "validation_mse"], history)

# -----------------------------------------------------------------------------
# 2. Demonstrate why a random point split can be optimistic
# -----------------------------------------------------------------------------
rng = np.random.default_rng(SEED + 10)
perm = rng.permutation(len(X))
cut = int(0.8 * len(perm))
tr_idx, pt_idx = perm[:cut], perm[cut:]
random_model, random_history, random_seconds = train_model(
    X[tr_idx], y[tr_idx], X[pt_idx], y[pt_idx], epochs=220, seed=SEED + 2
)

mse = nn.MSELoss()
with torch.no_grad():
    random_point_mse = mse(
        random_model(torch.from_numpy(X[pt_idx])), torch.from_numpy(y[pt_idx])
    ).item()
    random_unseen_trajectory_mse = mse(
        random_model(torch.from_numpy(Xv)), torch.from_numpy(yv)
    ).item()
    trajectory_unseen_trajectory_mse = mse(
        model(torch.from_numpy(Xv)), torch.from_numpy(yv)
    ).item()

torch.save(random_model.state_dict(), DATA / "random_point_split_surrogate.pt")
csvwrite(
    DATA / "random_point_training_history.csv",
    ["epoch", "train_mse", "random_point_validation_mse"],
    random_history,
)

# -----------------------------------------------------------------------------
# 3. In-range and out-of-range generalization
# -----------------------------------------------------------------------------
in_range = [("I1", 1.05, 0.08), ("I2", 1.45, 0.14), ("I3", 1.85, 0.25)]
out_range = [("E1", 0.65, 0.10), ("E2", 2.20, 0.20), ("E3", 1.50, 0.42)]
all_cases = [("interpolation",) + c for c in in_range] + [("extrapolation",) + c for c in out_range]

tt = np.linspace(0.0, 10.0, 301).astype("float32")
gen_rows = []
gen_metrics = []
for regime, case_id, omega0, zeta in all_cases:
    truth = oscillator(tt.astype(float), omega0, zeta)
    inp = torch.from_numpy(
        np.c_[tt, np.full_like(tt, omega0), np.full_like(tt, zeta)]
    )
    with torch.no_grad():
        pred = model(inp).squeeze().numpy()
    rel = float(np.linalg.norm(pred - truth) / np.linalg.norm(truth))
    gen_metrics.append((regime, case_id, omega0, zeta, rel))
    gen_rows.extend(
        (regime, case_id, float(t), omega0, zeta, float(a), float(b), float(b - a))
        for t, a, b in zip(tt, truth, pred)
    )

csvwrite(
    DATA / "generalization_predictions.csv",
    ["regime", "case_id", "t", "omega0", "zeta", "x_exact", "x_network", "error"],
    gen_rows,
)
csvwrite(
    DATA / "generalization_summary.csv",
    ["regime", "case_id", "omega0", "zeta", "relative_l2_error"],
    gen_metrics,
)

mean_interp_rel = float(np.mean([r[-1] for r in gen_metrics if r[0] == "interpolation"]))
mean_extra_rel = float(np.mean([r[-1] for r in gen_metrics if r[0] == "extrapolation"]))

# Backward-compatible held-out file used by older package consumers.
heldout_rows = [r for r in gen_rows if r[0] == "interpolation"]
csvwrite(
    DATA / "heldout_predictions.csv",
    ["regime", "case_id", "t", "omega0", "zeta", "x_exact", "x_network", "error"],
    heldout_rows,
)

# -----------------------------------------------------------------------------
# 4. Classical baselines: local RBF approximation and direct ODE integration
# -----------------------------------------------------------------------------
# The RBF baseline is a conventional nonlinear interpolant trained on exactly the
# same tabulated trajectories as the neural surrogate.  The direct solver uses
# the governing ODE and therefore represents the appropriate physics baseline
# for a one-off forward solve.
lo = np.array([0.0, 0.8, 0.03])
hi = np.array([10.0, 2.0, 0.35])
X_scaled = (X.astype(float) - lo) / (hi - lo)
Xv_scaled = (Xv.astype(float) - lo) / (hi - lo)
rbf_t0 = time.perf_counter()
rbf = RBFInterpolator(
    X_scaled,
    y[:, 0].astype(float),
    neighbors=64,
    kernel="gaussian",
    epsilon=3.0,
    smoothing=1e-5,
    degree=0,
)
rbf_build_seconds = time.perf_counter() - rbf_t0
rbf_pred_t0 = time.perf_counter()
rbf_val_pred = rbf(Xv_scaled)
rbf_validation_seconds = time.perf_counter() - rbf_pred_t0
rbf_validation_mse = float(np.mean((rbf_val_pred - yv[:, 0]) ** 2))

rbf_gen_metrics = []
for regime, case_id, omega0, zeta in all_cases:
    truth = oscillator(tt.astype(float), omega0, zeta)
    Xin = np.c_[tt, np.full_like(tt, omega0), np.full_like(tt, zeta)].astype(float)
    pred = rbf((Xin - lo) / (hi - lo))
    rel = float(np.linalg.norm(pred - truth) / np.linalg.norm(truth))
    rbf_gen_metrics.append((regime, case_id, omega0, zeta, rel))

rbf_interp_rel = float(np.mean([r[-1] for r in rbf_gen_metrics if r[0] == "interpolation"]))
rbf_extra_rel = float(np.mean([r[-1] for r in rbf_gen_metrics if r[0] == "extrapolation"]))
csvwrite(
    DATA / "rbf_generalization_summary.csv",
    ["regime", "case_id", "omega0", "zeta", "relative_l2_error"],
    rbf_gen_metrics,
)

# Direct numerical ODE solve.  We time 60 complete trajectories to avoid a
# misleading single-call measurement dominated by timer noise.
def oscillator_rhs(t, state, omega0, zeta):
    x, v = state
    return [v, -2.0 * zeta * omega0 * v - omega0 * omega0 * x]

def direct_trajectory(omega0, zeta, t_eval):
    sol = solve_ivp(
        oscillator_rhs,
        (float(t_eval[0]), float(t_eval[-1])),
        [1.0, 0.0],
        t_eval=np.asarray(t_eval, dtype=float),
        args=(float(omega0), float(zeta)),
        rtol=1e-10,
        atol=1e-12,
        method="DOP853",
    )
    return sol.y[0]

sample_solver_params = train_params[:60]
solver_t0 = time.perf_counter()
solver_errors = []
for _, w0, z0 in sample_solver_params:
    pred = direct_trajectory(w0, z0, tt)
    exact = oscillator(tt.astype(float), w0, z0)
    solver_errors.append(np.linalg.norm(pred - exact) / np.linalg.norm(exact))
solver_seconds_60 = time.perf_counter() - solver_t0
solver_seconds_per_trajectory = solver_seconds_60 / len(sample_solver_params)
solver_mean_rel = float(np.mean(solver_errors))

# Time neural evaluation of the same 60 trajectories.  Training time is kept
# separate because a surrogate only amortizes that cost when it is reused.
network_t0 = time.perf_counter()
with torch.no_grad():
    for _, w0, z0 in sample_solver_params:
        xin = torch.from_numpy(
            np.c_[tt, np.full_like(tt, w0), np.full_like(tt, z0)].astype("float32")
        )
        _ = model(xin)
network_seconds_60 = time.perf_counter() - network_t0
network_seconds_per_trajectory = network_seconds_60 / len(sample_solver_params)

csvwrite(
    DATA / "baseline_comparison.csv",
    ["method", "quantity", "value"],
    [
        ("neural_surrogate", "trajectory_validation_mse", history[-1][2]),
        ("rbf_interpolant", "trajectory_validation_mse", rbf_validation_mse),
        ("neural_surrogate", "mean_interpolation_relative_l2", mean_interp_rel),
        ("rbf_interpolant", "mean_interpolation_relative_l2", rbf_interp_rel),
        ("neural_surrogate", "mean_extrapolation_relative_l2", mean_extra_rel),
        ("rbf_interpolant", "mean_extrapolation_relative_l2", rbf_extra_rel),
        ("direct_ode_solver", "mean_relative_l2", solver_mean_rel),
        ("direct_ode_solver", "seconds_per_trajectory", solver_seconds_per_trajectory),
        ("neural_surrogate", "seconds_per_trajectory", network_seconds_per_trajectory),
        ("neural_surrogate", "training_seconds", train_seconds),
        ("rbf_interpolant", "build_seconds", rbf_build_seconds),
    ],
)

# -----------------------------------------------------------------------------
# 5. Inverse identification through the differentiable surrogate
# -----------------------------------------------------------------------------
true_w, true_z = 1.55, 0.12
rng = np.random.default_rng(SEED + 4)
tobs = np.linspace(0.0, 8.0, 40).astype("float32")
clean = oscillator(tobs.astype(float), true_w, true_z)
noisy = clean + rng.normal(0.0, 0.015, len(tobs))

a = torch.tensor([0.0, 0.0], requires_grad=True)
invopt = torch.optim.Adam([a], lr=0.06)
tobst = torch.from_numpy(tobs[:, None])
yobst = torch.from_numpy(noisy.astype("float32")[:, None])
trace = []
for step in range(260):
    w = 0.8 + 1.2 * torch.sigmoid(a[0])
    z = 0.03 + 0.32 * torch.sigmoid(a[1])
    inp = torch.cat([tobst, w.expand_as(tobst), z.expand_as(tobst)], dim=1)
    loss = ((model(inp) - yobst) ** 2).mean()
    invopt.zero_grad()
    loss.backward()
    invopt.step()
    trace.append((step + 1, float(loss.detach()), float(w.detach()), float(z.detach())))

csvwrite(
    DATA / "inverse_trace.csv",
    ["step", "mse", "omega0_estimate", "zeta_estimate"],
    trace,
)
csvwrite(
    DATA / "inverse_observations.csv",
    ["t", "x_clean", "x_noisy"],
    zip(tobs, clean, noisy),
)
wh, zh = trace[-1][2], trace[-1][3]

# -----------------------------------------------------------------------------
# Figures
# -----------------------------------------------------------------------------
# Fig. 1: compact network schematic
fig, ax = plt.subplots(figsize=(6.9, 1.75))
ax.axis("off")
ax.set_xlim(0, 1)
ax.set_ylim(0, 1)


def box(x, y0, w, h, text, fc="white", ec="0.55"):
    patch = FancyBboxPatch(
        (x, y0),
        w,
        h,
        boxstyle="round,pad=0.009,rounding_size=.018",
        fc=fc,
        ec=ec,
        lw=0.8,
    )
    ax.add_patch(patch)
    ax.text(x + w / 2, y0 + h / 2, text, ha="center", va="center", fontsize=8)


def arrow(x0, y0, x1, y1):
    ax.add_patch(
        FancyArrowPatch(
            (x0, y0),
            (x1, y1),
            arrowstyle="-|>",
            mutation_scale=8,
            lw=0.8,
            color="0.35",
        )
    )


box(0.03, 0.37, 0.16, 0.26, "inputs\n$t,\\omega_0,\\zeta$")
box(0.29, 0.37, 0.15, 0.26, "hidden\nlayer 1")
box(0.51, 0.37, 0.15, 0.26, "hidden\nlayer 2")
box(0.73, 0.37, 0.11, 0.26, "hidden\nlayer 3")
box(0.89, 0.37, 0.08, 0.26, "$\\hat{x}$")
for a0, a1 in [(0.19, 0.29), (0.44, 0.51), (0.66, 0.73), (0.84, 0.89)]:
    arrow(a0, 0.50, a1, 0.50)
ax.text(0.5, 0.81, "A neural network as a parameterized nonlinear approximation", ha="center", fontsize=9, fontweight="bold")
ax.text(0.5, 0.19, "Training chooses the weights; evaluation applies the learned map.", ha="center", fontsize=7.5, color="0.35")
fig.tight_layout()
save(fig, "network_schematic")

# Fig. 2: learning curve and representative held-out trajectories
fig, axs = plt.subplots(1, 2, figsize=(7.05, 2.45))
axs[0].semilogy([r[0] for r in history], [r[1] for r in history], label="training")
axs[0].semilogy([r[0] for r in history], [r[2] for r in history], label="unseen trajectories")
axs[0].set_xlabel("epoch")
axs[0].set_ylabel("mean-squared error")
axs[0].legend(frameon=False)
panel_label(axs[0], "(a)")
for idx, (case_id, omega0, zeta) in enumerate(in_range):
    rr = np.asarray([r for r in gen_rows if r[1] == case_id], dtype=object)
    tplot = rr[:, 2].astype(float)
    exact = rr[:, 5].astype(float)
    pred = rr[:, 6].astype(float)
    axs[1].plot(tplot, exact, lw=1.15, label="exact" if idx == 0 else None)
    axs[1].plot(tplot, pred, "--", lw=1.0, label="network" if idx == 0 else None)
axs[1].set_xlabel("time")
axs[1].set_ylabel("displacement")
axs[1].legend(frameon=False)
panel_label(axs[1], "(b)")
fig.tight_layout()
save(fig, "oscillator_learning")

# Fig. 3: physical validation split and leakage comparison
fig, axs = plt.subplots(1, 2, figsize=(7.05, 2.45))
train_arr = np.asarray([(w, z) for _, w, z in train_params])
val_arr = np.asarray([(w, z) for _, w, z in val_params])
axs[0].scatter(train_arr[:, 0], train_arr[:, 1], s=13, alpha=0.65, label="training systems")
axs[0].scatter(val_arr[:, 0], val_arr[:, 1], s=20, marker="x", label="held-out systems")
axs[0].set_xlabel(r"natural frequency $\omega_0$")
axs[0].set_ylabel(r"damping ratio $\zeta$")
validation_legend_handles, validation_legend_labels = axs[0].get_legend_handles_labels()
panel_label(axs[0], "(a)")

labels = ["random-point\nvalidation", "same model on\nunseen systems", "trajectory-split\nunseen systems"]
vals = [random_point_mse, random_unseen_trajectory_mse, trajectory_unseen_trajectory_mse]
axs[1].bar(np.arange(3), vals)
axs[1].set_yscale("log")
axs[1].set_ylabel("mean-squared error")
axs[1].set_xticks(np.arange(3), labels)
axs[1].tick_params(axis="x", labelsize=6.8)
panel_label(axs[1], "(b)")
fig.legend(validation_legend_handles, validation_legend_labels, frameon=False, ncol=2,
           loc="lower center", bbox_to_anchor=(0.5, -0.02))
fig.subplots_adjust(bottom=0.24, wspace=0.30)
fig.savefig(FIG_DIR / "validation_protocol.pdf", bbox_inches="tight")
fig.savefig(FIG_DIR / "validation_protocol.png", dpi=240, bbox_inches="tight")
fig.savefig(PLOT_DIR / "validation_protocol.png", dpi=240, bbox_inches="tight")
plt.close(fig)

# Fig. 4: interpolation versus extrapolation
fig, axs = plt.subplots(1, 2, figsize=(7.05, 2.45))
for case_id, label in [("I2", "inside training range"), ("E2", "outside training range")]:
    rr = np.asarray([r for r in gen_rows if r[1] == case_id], dtype=object)
    tplot = rr[:, 2].astype(float)
    exact = rr[:, 5].astype(float)
    pred = rr[:, 6].astype(float)
    axs[0].plot(tplot, exact, lw=1.15, label=f"exact: {label}")
    axs[0].plot(tplot, pred, "--", lw=1.0, label=f"network: {label}")
axs[0].set_xlabel("time")
axs[0].set_ylabel("displacement")
axs[0].legend(frameon=False, fontsize=6.5)
panel_label(axs[0], "(a)")

case_labels = [r[1] for r in gen_metrics]
case_errors = [r[-1] for r in gen_metrics]
axs[1].bar(np.arange(len(case_labels)), case_errors)
axs[1].axvline(2.5, color="0.5", lw=0.8, ls=":")
axs[1].set_yscale("log")
axs[1].set_xticks(np.arange(len(case_labels)), case_labels)
axs[1].set_xlabel("I: interpolation; E: extrapolation")
axs[1].set_ylabel(r"relative $L^2$ error")
panel_label(axs[1], "(b)")
fig.tight_layout()
save(fig, "generalization_regimes")

# Fig. 5: neural versus classical approximation baselines
fig, axs = plt.subplots(1, 2, figsize=(7.05, 2.45))
method_labels = ["neural\nsurrogate", "local RBF\ninterpolant"]
axs[0].bar(np.arange(2), [mean_interp_rel, rbf_interp_rel])
axs[0].set_yscale("log")
axs[0].set_xticks(np.arange(2), method_labels)
axs[0].set_ylabel(r"mean interpolation relative $L^2$ error")
panel_label(axs[0], "(a)")
axs[1].bar(
    np.arange(2),
    [solver_seconds_per_trajectory * 1e3, network_seconds_per_trajectory * 1e3],
)
axs[1].set_yscale("log")
axs[1].set_xticks(np.arange(2), ["direct ODE\nsolver", "neural\nevaluation"])
axs[1].set_ylabel("milliseconds per trajectory")
panel_label(axs[1], "(b)")
fig.tight_layout()
save(fig, "baseline_comparison")

# Fig. 6: inverse identification through the differentiable surrogate
fine = np.linspace(0.0, 8.0, 400).astype("float32")
inp = torch.from_numpy(np.c_[fine, np.full_like(fine, wh), np.full_like(fine, zh)])
with torch.no_grad():
    fit = model(inp).squeeze().numpy()

fig, axs = plt.subplots(1, 2, figsize=(7.05, 2.45))
axs[0].scatter(tobs, noisy, s=11, label="noisy observations", zorder=3)
axs[0].plot(fine, oscillator(fine.astype(float), true_w, true_z), lw=1.2, label="true trajectory")
axs[0].plot(fine, fit, "--", lw=1.1, label="surrogate fit")
axs[0].set_xlabel("time")
axs[0].set_ylabel("displacement")
axs[0].legend(frameon=False, fontsize=6.8)
panel_label(axs[0], "(a)")
axs[1].plot([r[0] for r in trace], [r[2] for r in trace], label=r"$\omega_0$ estimate")
axs[1].plot([r[0] for r in trace], [r[3] for r in trace], label=r"$\zeta$ estimate")
axs[1].axhline(true_w, lw=0.8, ls=":", color="0.4")
axs[1].axhline(true_z, lw=0.8, ls=":", color="0.4")
axs[1].set_xlabel("inverse-optimization step")
axs[1].set_ylabel("parameter value")
axs[1].legend(frameon=False, fontsize=6.8)
panel_label(axs[1], "(b)")
fig.tight_layout()
save(fig, "inverse_identification")

# -----------------------------------------------------------------------------
# Summary and environment
# -----------------------------------------------------------------------------
summary = {
    "train_mse": history[-1][1],
    "trajectory_validation_mse": history[-1][2],
    "random_point_validation_mse": random_point_mse,
    "random_split_unseen_trajectory_mse": random_unseen_trajectory_mse,
    "trajectory_split_unseen_trajectory_mse": trajectory_unseen_trajectory_mse,
    "mean_interpolation_relative_l2": mean_interp_rel,
    "mean_extrapolation_relative_l2": mean_extra_rel,
    "rbf_validation_mse": rbf_validation_mse,
    "rbf_mean_interpolation_relative_l2": rbf_interp_rel,
    "rbf_mean_extrapolation_relative_l2": rbf_extra_rel,
    "direct_solver_mean_relative_l2": solver_mean_rel,
    "direct_solver_seconds_per_trajectory": solver_seconds_per_trajectory,
    "network_seconds_per_trajectory": network_seconds_per_trajectory,
    "rbf_build_seconds": rbf_build_seconds,
    "true_omega0": true_w,
    "estimated_omega0": wh,
    "true_zeta": true_z,
    "estimated_zeta": zh,
    "trajectory_model_training_seconds": train_seconds,
    "random_split_model_training_seconds": random_seconds,
    "seed": SEED,
    "python": sys.version.split()[0],
    "numpy": np.__version__,
    "torch": torch.__version__,
    "platform": platform.platform(),
}
with open(DATA / "benchmark_summary.json", "w", encoding="utf-8") as f:
    json.dump(summary, f, indent=2)
csvwrite(DATA / "benchmark_summary.csv", ["metric", "value"], summary.items())

macro_text = f"""% Auto-generated by code/reproduce_workflow.py
\\newcommand{{\\TrainMSE}}{{{summary['train_mse']:.3e}}}
\\newcommand{{\\TrajectoryValMSE}}{{{summary['trajectory_validation_mse']:.3e}}}
\\newcommand{{\\RandomPointMSE}}{{{summary['random_point_validation_mse']:.3e}}}
\\newcommand{{\\RandomUnseenMSE}}{{{summary['random_split_unseen_trajectory_mse']:.3e}}}
\\newcommand{{\\InterpRel}}{{{summary['mean_interpolation_relative_l2']:.3f}}}
\\newcommand{{\\ExtraRel}}{{{summary['mean_extrapolation_relative_l2']:.3f}}}
\\newcommand{{\\TrueOmega}}{{{summary['true_omega0']:.2f}}}
\\newcommand{{\\EstOmega}}{{{summary['estimated_omega0']:.4f}}}
\\newcommand{{\\TrueZeta}}{{{summary['true_zeta']:.2f}}}
\\newcommand{{\\EstZeta}}{{{summary['estimated_zeta']:.4f}}}
"""
(ROOT / "manuscript" / "benchmark_macros.tex").write_text(macro_text)
(ROOT / "supplementary").mkdir(parents=True, exist_ok=True)
(ROOT / "supplementary" / "benchmark_macros.tex").write_text(macro_text)

print(json.dumps(summary, indent=2))
