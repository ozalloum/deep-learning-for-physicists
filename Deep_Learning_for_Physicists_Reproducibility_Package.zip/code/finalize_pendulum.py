#!/usr/bin/env python3
"""Regenerate the simple-pendulum Figure 5 from frozen benchmark outputs."""
from __future__ import annotations

import csv
import pickle
from pathlib import Path

import numpy as np

from pendulum_regime import (
    DATA,
    ROTATION_OMEGA,
    TRAIN_OMEGA,
    VALIDATION_OMEGA,
    plot_figure,
)


ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    summary_path = DATA / "pendulum_multiseed.csv"
    if not summary_path.exists():
        raise FileNotFoundError(
            f"Missing {summary_path}; run pendulum_regime.py first or restore the frozen outputs."
        )

    rows = []
    with summary_path.open(newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            rows.append(
                [
                    float(row["seed"]),
                    float(row["heldout_oscillation_mean_relative_l2"]),
                    float(row["heldout_oscillation_system_sd"]),
                    float(row["rotation_regime_mean_relative_l2"]),
                    float(row["rotation_regime_system_sd"]),
                    float(row["rotation_to_oscillation_error_ratio"]),
                    float(row["iterations"]),
                    float(row["training_seconds"]),
                ]
            )
    rows_array = np.asarray(rows, dtype=float)

    model_path = DATA / "pendulum_surrogate_seed123.pkl"
    with model_path.open("rb") as handle:
        model = pickle.load(handle)

    plot_figure(model, rows_array, TRAIN_OMEGA, VALIDATION_OMEGA, ROTATION_OMEGA)
    print("Regenerated pendulum figures from frozen outputs.")
    print("Figure:", ROOT / "plots" / "pendulum_regime_shift.png")


if __name__ == "__main__":
    main()
