#!/usr/bin/env python3
"""Generate the familiar simple-pendulum regime-shift benchmark.

The pendulum is trained only on libration (ordinary oscillation).  Tests above
the separatrix have enough initial angular speed for continuous rotation.  The
example is intentionally elementary so that the qualitative change is visible
without specialist PDE notation.
"""
from __future__ import annotations

import csv
import math
import pickle
import random
import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.integrate import solve_ivp
from sklearn.neural_network import MLPRegressor

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
FIG = ROOT / "manuscript" / "figures"
PLOTS = ROOT / "plots"
for directory in (DATA, FIG, PLOTS):
    directory.mkdir(parents=True, exist_ok=True)

G = 9.81
LENGTH = 1.0
CRITICAL_OMEGA = 2.0 * math.sqrt(G / LENGTH)
CRITICAL_ENERGY = 2.0 * G / LENGTH
SEEDS = [123, 137, 151]
TRAIN_OMEGA = np.linspace(0.8, 5.5, 20)
VALIDATION_OMEGA = np.array([1.0, 2.0, 3.0, 4.0, 5.0, 5.8])
ROTATION_OMEGA = np.array([6.7, 7.1, 7.6, 8.0])
TRAIN_T = np.linspace(0.0, 3.0, 91)
TRACE_T = np.linspace(0.0, 3.0, 241)

plt.rcParams.update(
    {
        "font.size": 8.4,
        "axes.labelsize": 8.4,
        "axes.titlesize": 8.6,
        "xtick.labelsize": 7.3,
        "ytick.labelsize": 7.3,
        "legend.fontsize": 6.8,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "savefig.bbox": "tight",
    }
)


def panel_label(axis, label: str) -> None:
    axis.text(
        -0.13,
        1.04,
        label,
        transform=axis.transAxes,
        ha="left",
        va="bottom",
        fontweight="bold",
        clip_on=False,
    )


def pendulum_solution(omega0: float, times: np.ndarray) -> np.ndarray:
    """Unwrapped angle for theta'' + (g/l) sin(theta) = 0."""

    def rhs(_time: float, state: np.ndarray) -> list[float]:
        return [state[1], -(G / LENGTH) * math.sin(state[0])]

    result = solve_ivp(
        rhs,
        (float(times[0]), float(times[-1])),
        [0.0, float(omega0)],
        t_eval=times,
        rtol=1e-9,
        atol=1e-11,
        max_step=0.02,
    )
    if not result.success:
        raise RuntimeError(result.message)
    return result.y[0]


def make_data(omegas: np.ndarray, times: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    features: list[np.ndarray] = []
    targets: list[np.ndarray] = []
    system_ids: list[int] = []
    for system_id, omega0 in enumerate(omegas):
        theta = pendulum_solution(float(omega0), times)
        features.append(np.c_[times, np.full(times.size, omega0)])
        targets.append(theta)
        system_ids.extend([system_id] * times.size)
    return (
        np.vstack(features).astype("float64"),
        np.concatenate(targets).astype("float64"),
        np.asarray(system_ids, dtype=int),
    )


def fit_model(features: np.ndarray, targets: np.ndarray, seed: int) -> MLPRegressor:
    model = MLPRegressor(
        hidden_layer_sizes=(32, 32),
        activation="tanh",
        solver="adam",
        learning_rate_init=3e-3,
        batch_size=256,
        max_iter=500,
        tol=1e-5,
        n_iter_no_change=30,
        random_state=seed,
    )
    model.fit(features, targets)
    return model


def relative_errors(
    model: MLPRegressor,
    features: np.ndarray,
    targets: np.ndarray,
    system_ids: np.ndarray,
    n_systems: int,
) -> np.ndarray:
    prediction = model.predict(features)
    values = []
    for system_id in range(n_systems):
        mask = system_ids == system_id
        values.append(
            float(
                np.linalg.norm(prediction[mask] - targets[mask])
                / np.linalg.norm(targets[mask])
            )
        )
    return np.asarray(values)


def write_systems() -> None:
    with (DATA / "pendulum_systems.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "split",
                "system_id",
                "initial_angular_speed",
                "initial_energy",
                "critical_angular_speed",
                "separatrix_energy",
                "qualitative_regime",
            ]
        )
        groups = [
            ("train", TRAIN_OMEGA, "oscillation"),
            ("validation", VALIDATION_OMEGA, "oscillation"),
            ("regime_shift", ROTATION_OMEGA, "rotation"),
        ]
        for split, omegas, regime in groups:
            for system_id, omega0 in enumerate(omegas):
                writer.writerow(
                    [
                        split,
                        system_id,
                        float(omega0),
                        0.5 * float(omega0) ** 2,
                        CRITICAL_OMEGA,
                        CRITICAL_ENERGY,
                        regime,
                    ]
                )


def plot_figure(
    model: MLPRegressor,
    rows: np.ndarray,
    train_omega: np.ndarray,
    validation_omega: np.ndarray,
    rotation_omega: np.ndarray,
) -> None:
    fig, axes = plt.subplots(1, 3, figsize=(10.8, 3.25))

    axis = axes[0]
    all_omega = np.r_[train_omega, validation_omega, rotation_omega]
    axis.axvspan(0, CRITICAL_OMEGA, color="#4c78a8", alpha=0.08)
    axis.axvspan(CRITICAL_OMEGA, all_omega.max() + 0.35, color="#e45756", alpha=0.08)
    axis.axvline(CRITICAL_OMEGA, color="black", lw=1.1, ls="--", label=r"separatrix $\omega_c$")
    axis.scatter(
        train_omega,
        0.5 * train_omega**2,
        s=15,
        alpha=0.65,
        color="#4c78a8",
        label="training: oscillation",
    )
    axis.scatter(
        validation_omega,
        0.5 * validation_omega**2,
        s=30,
        marker="s",
        facecolors="none",
        linewidths=1.0,
        color="#4c78a8",
        label="held-out: oscillation",
    )
    axis.scatter(
        rotation_omega,
        0.5 * rotation_omega**2,
        s=32,
        marker="^",
        color="#e45756",
        label="regime shift: rotation",
    )
    axis.axhline(CRITICAL_ENERGY, color="0.35", lw=0.8, ls=":")
    axis.set_xlabel(r"initial angular speed $\omega_0$ (rad s$^{-1}$)")
    axis.set_ylabel(r"normalized energy $E_0/\ell^2=\omega_0^2/2$")
    axis.set_xlim(0.4, 8.4)
    axis.set_ylim(0, 35)
    axis.legend(frameon=False, loc="upper left", fontsize=6.0)
    panel_label(axis, "(a)")

    axis = axes[1]
    representatives = [
        ("oscillation", float(validation_omega[-1]), "#4c78a8"),
        ("rotation", float(rotation_omega[1]), "#e45756"),
    ]
    for label, omega0, color in representatives:
        exact = pendulum_solution(omega0, TRACE_T)
        features = np.c_[TRACE_T, np.full(TRACE_T.size, omega0)]
        prediction = model.predict(features)
        axis.plot(TRACE_T, exact / math.pi, color=color, lw=1.7, label=f"exact: {label}")
        axis.plot(
            TRACE_T,
            prediction / math.pi,
            color=color,
            lw=1.25,
            ls="--",
            label=f"surrogate: {label}",
        )
    axis.axhline(0, color="0.75", lw=0.6)
    axis.set_xlabel("time $t$ (s)")
    axis.set_ylabel(r"unwrapped angle $\theta/\pi$")
    trajectory_legend_handles, trajectory_legend_labels = axis.get_legend_handles_labels()
    panel_label(axis, "(b)")

    axis = axes[2]
    x_positions = np.array([0, 1])
    means = np.array([rows[:, 1].mean(), rows[:, 3].mean()])
    standard_deviations = np.array(
        [rows[:, 1].std(ddof=1), rows[:, 3].std(ddof=1)]
    )
    axis.bar(
        x_positions,
        means,
        yerr=standard_deviations,
        capsize=3,
        width=0.58,
        alpha=0.8,
        color=["#4c78a8", "#e45756"],
    )
    for row in rows:
        axis.plot(x_positions, [row[1], row[3]], "o-", ms=3, lw=0.7, color="0.25", alpha=0.65)
    axis.set_xticks(x_positions, ["held-out\noscillation", "rotation\nregime shift"])
    axis.set_ylabel("mean relative $L^2$ error")
    axis.set_yscale("log")
    panel_label(axis, "(c)")

    fig.legend(
        trajectory_legend_handles,
        trajectory_legend_labels,
        frameon=False,
        ncol=2,
        loc="lower center",
        bbox_to_anchor=(0.5, -0.02),
        columnspacing=2.0,
        handlelength=2.4,
    )
    fig.subplots_adjust(wspace=0.38, bottom=0.30)
    fig.savefig(FIG / "pendulum_regime_shift.pdf", bbox_inches="tight")
    fig.savefig(FIG / "pendulum_regime_shift.png", dpi=240, bbox_inches="tight")
    fig.savefig(PLOTS / "pendulum_regime_shift.png", dpi=240, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    random.seed(123)
    np.random.seed(123)
    write_systems()

    train_features, train_targets, _ = make_data(TRAIN_OMEGA, TRAIN_T)
    validation_features, validation_targets, validation_ids = make_data(VALIDATION_OMEGA, TRAIN_T)
    rotation_features, rotation_targets, rotation_ids = make_data(ROTATION_OMEGA, TRAIN_T)

    rows = []
    representative_model = None
    for seed in SEEDS:
        started = time.perf_counter()
        model = fit_model(train_features, train_targets, seed)
        seconds = time.perf_counter() - started
        validation_values = relative_errors(
            model,
            validation_features,
            validation_targets,
            validation_ids,
            len(VALIDATION_OMEGA),
        )
        rotation_values = relative_errors(
            model,
            rotation_features,
            rotation_targets,
            rotation_ids,
            len(ROTATION_OMEGA),
        )
        rows.append(
            [
                seed,
                float(validation_values.mean()),
                float(validation_values.std(ddof=1)),
                float(rotation_values.mean()),
                float(rotation_values.std(ddof=1)),
                float(rotation_values.mean() / validation_values.mean()),
                model.n_iter_,
                seconds,
            ]
        )
        if seed == SEEDS[0]:
            representative_model = model
            with (DATA / "pendulum_surrogate_seed123.pkl").open("wb") as handle:
                pickle.dump(model, handle, protocol=pickle.HIGHEST_PROTOCOL)
            with (DATA / "pendulum_training_history.csv").open("w", newline="") as handle:
                writer = csv.writer(handle)
                writer.writerow(["iteration", "training_loss"])
                writer.writerows(enumerate(model.loss_curve_, start=1))
        print(seed, rows[-1])

    rows_array = np.asarray(rows, dtype=float)
    with (DATA / "pendulum_multiseed.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "seed",
                "heldout_oscillation_mean_relative_l2",
                "heldout_oscillation_system_sd",
                "rotation_regime_mean_relative_l2",
                "rotation_regime_system_sd",
                "rotation_to_oscillation_error_ratio",
                "iterations",
                "training_seconds",
            ]
        )
        writer.writerows(rows)

    summary = [
        (
            "heldout_oscillation_mean_relative_l2",
            float(rows_array[:, 1].mean()),
            float(rows_array[:, 1].std(ddof=1)),
        ),
        (
            "rotation_regime_mean_relative_l2",
            float(rows_array[:, 3].mean()),
            float(rows_array[:, 3].std(ddof=1)),
        ),
        (
            "rotation_to_oscillation_error_ratio",
            float(rows_array[:, 5].mean()),
            float(rows_array[:, 5].std(ddof=1)),
        ),
    ]
    with (DATA / "pendulum_summary.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["metric", "mean_across_seeds", "std_across_seeds"])
        writer.writerows(summary)

    trace_rows = []
    for label, omega0, regime in [
        ("held-out oscillation", float(VALIDATION_OMEGA[-1]), "oscillation"),
        ("rotation regime shift", float(ROTATION_OMEGA[1]), "rotation"),
    ]:
        exact = pendulum_solution(omega0, TRACE_T)
        prediction = representative_model.predict(
            np.c_[TRACE_T, np.full(TRACE_T.size, omega0)]
        )
        for t_value, exact_value, prediction_value in zip(TRACE_T, exact, prediction):
            trace_rows.append(
                [
                    label,
                    float(t_value),
                    omega0,
                    CRITICAL_OMEGA,
                    0.5 * omega0**2,
                    regime,
                    float(exact_value),
                    float(prediction_value),
                ]
            )
    with (DATA / "pendulum_example_traces.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "case",
                "time",
                "initial_angular_speed",
                "critical_angular_speed",
                "initial_energy",
                "qualitative_regime",
                "theta_exact",
                "theta_surrogate",
            ]
        )
        writer.writerows(trace_rows)

    plot_figure(
        representative_model,
        rows_array,
        TRAIN_OMEGA,
        VALIDATION_OMEGA,
        ROTATION_OMEGA,
    )
    print("critical angular speed", CRITICAL_OMEGA)
    print("summary", summary)


if __name__ == "__main__":
    main()
