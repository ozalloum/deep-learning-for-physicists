#!/usr/bin/env python3
from __future__ import annotations
import csv, math, random, time
from pathlib import Path
import numpy as np
import torch
from torch import nn

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'
torch.set_num_threads(1)
SEED_BASE = 17
SEEDS = [17, 31, 47]

def oscillator(t, omega0, zeta):
    t=np.asarray(t,dtype=float)
    disc=np.maximum(1-zeta*zeta,1e-12)
    wd=omega0*np.sqrt(disc)
    return np.exp(-zeta*omega0*t)*(np.cos(wd*t)+zeta/np.sqrt(disc)*np.sin(wd*t))

def make_data(nparam, ntime, seed):
    rng=np.random.default_rng(seed); t=np.linspace(0,10,ntime)
    X=[]; y=[]
    for _ in range(nparam):
        omega0=rng.uniform(0.8,2.0); zeta=rng.uniform(0.03,0.35); yy=oscillator(t,omega0,zeta)
        X.append(np.c_[t,np.full_like(t,omega0),np.full_like(t,zeta)]); y.append(yy[:,None])
    return np.vstack(X).astype('float32'),np.vstack(y).astype('float32')

class MLP(nn.Module):
    def __init__(self,width=48,depth=3):
        super().__init__(); layers=[nn.Linear(3,width),nn.Tanh()]
        for _ in range(depth-1): layers += [nn.Linear(width,width),nn.Tanh()]
        layers += [nn.Linear(width,1)]; self.net=nn.Sequential(*layers)
    def forward(self,x):
        lo=torch.tensor([0.0,0.8,0.03],dtype=x.dtype,device=x.device)
        hi=torch.tensor([10.0,2.0,0.35],dtype=x.dtype,device=x.device)
        return self.net(2*(x-lo)/(hi-lo)-1)

def train_model(X,y,Xv,yv,epochs,seed):
    torch.manual_seed(seed); random.seed(seed); np.random.seed(seed)
    model=MLP(); opt=torch.optim.Adam(model.parameters(),lr=2e-3); mse=nn.MSELoss()
    Xt=torch.from_numpy(X); yt=torch.from_numpy(y); Xvt=torch.from_numpy(Xv); yvt=torch.from_numpy(yv)
    t0=time.perf_counter()
    for _ in range(epochs):
        perm=torch.randperm(len(Xt)); model.train()
        for i in range(0,len(Xt),256):
            q=perm[i:i+256]; loss=mse(model(Xt[q]),yt[q]); opt.zero_grad(); loss.backward(); opt.step()
    model.eval()
    with torch.no_grad(): val=float(mse(model(Xvt),yvt))
    return model,val,time.perf_counter()-t0

X,y=make_data(60,60,SEED_BASE); Xv,yv=make_data(15,60,SEED_BASE+1)
rng=np.random.default_rng(SEED_BASE+10); perm=rng.permutation(len(X)); cut=int(0.8*len(perm)); tr_idx,pt_idx=perm[:cut],perm[cut:]
in_range=[('I1',1.05,0.08),('I2',1.45,0.14),('I3',1.85,0.25)]
out_range=[('E1',0.65,0.10),('E2',2.20,0.20),('E3',1.50,0.42)]
tt=np.linspace(0,10,301).astype('float32'); mse=nn.MSELoss()
rows=[]
for seed in SEEDS:
    traj,traj_val,sec=train_model(X,y,Xv,yv,300,seed)
    rel_in=[]; rel_out=[]
    for group,cases in [('interpolation',in_range),('extrapolation',out_range)]:
        vals=[]
        for _,omega,zeta in cases:
            truth=oscillator(tt.astype(float),omega,zeta)
            inp=torch.from_numpy(np.c_[tt,np.full_like(tt,omega),np.full_like(tt,zeta)])
            with torch.no_grad(): pred=traj(inp).squeeze().numpy()
            vals.append(float(np.linalg.norm(pred-truth)/np.linalg.norm(truth)))
        if group=='interpolation': rel_in=vals
        else: rel_out=vals
    random_model,rand_pt,sec2=train_model(X[tr_idx],y[tr_idx],X[pt_idx],y[pt_idx],220,seed+100)
    with torch.no_grad(): unseen=float(mse(random_model(torch.from_numpy(Xv)),torch.from_numpy(yv)))
    rows.append([seed,traj_val,np.mean(rel_in),np.mean(rel_out),rand_pt,unseen,sec,sec2])
    print(seed, rows[-1])

with open(DATA/'multiseed_robustness.csv','w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['seed','trajectory_validation_mse','mean_interpolation_relative_l2','mean_extrapolation_relative_l2','random_point_validation_mse','random_split_unseen_trajectory_mse','trajectory_training_seconds','random_training_seconds']); w.writerows(rows)
arr=np.asarray([r[1:6] for r in rows],float)
metrics=['trajectory_validation_mse','mean_interpolation_relative_l2','mean_extrapolation_relative_l2','random_point_validation_mse','random_split_unseen_trajectory_mse']
with open(DATA/'multiseed_summary.csv','w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['metric','mean','std','min','max'])
    for j,m in enumerate(metrics): w.writerow([m,arr[:,j].mean(),arr[:,j].std(ddof=1),arr[:,j].min(),arr[:,j].max()])
print('done')
