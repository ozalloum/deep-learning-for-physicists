#!/usr/bin/env python3
from pathlib import Path
import csv, json
import numpy as np
import matplotlib.pyplot as plt
import torch
from torch import nn

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT/'data'
FIG = ROOT/'manuscript'/'figures'
PLOTS = ROOT/'plots'

plt.rcParams.update({
    'font.size': 8.6,
    'axes.labelsize': 8.6,
    'axes.titlesize': 8.8,
    'xtick.labelsize': 7.5,
    'ytick.labelsize': 7.5,
    'legend.fontsize': 7.2,
    'figure.dpi': 170,
    'savefig.bbox': 'tight',
    'axes.spines.top': False,
    'axes.spines.right': False,
})

def panel_label(ax, label):
    # Journal-style panel tag: outside the data/plotting rectangle, in the upper-left margin.
    ax.text(-0.12, 1.04, label, transform=ax.transAxes,
            ha='left', va='bottom', fontweight='bold', clip_on=False)

def save(fig, name):
    # Leave deliberate headroom for outside panel labels.
    fig.tight_layout(pad=1.0)
    fig.savefig(FIG/f'{name}.pdf', bbox_inches='tight')
    fig.savefig(FIG/f'{name}.png', dpi=240, bbox_inches='tight')
    fig.savefig(PLOTS/f'{name}.png', dpi=240, bbox_inches='tight')
    plt.close(fig)

def read_csv(name):
    with open(DATA/name, newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))

with open(DATA/'benchmark_summary.json', encoding='utf-8') as f:
    summary = json.load(f)

gen = read_csv('generalization_predictions.csv')
gen_sum = read_csv('generalization_summary.csv')
hist = read_csv('training_history.csv')
split = read_csv('trajectory_parameter_split.csv')
inv_obs = read_csv('inverse_observations.csv')
trace = read_csv('inverse_trace.csv')
rbf_sum = read_csv('rbf_generalization_summary.csv')

# Figure: learning curve + representative in-range trajectories
fig, axs = plt.subplots(1, 2, figsize=(7.05, 2.45))
axs[0].semilogy([int(r['epoch']) for r in hist], [float(r['train_mse']) for r in hist], label='training')
axs[0].semilogy([int(r['epoch']) for r in hist], [float(r['validation_mse']) for r in hist], label='unseen trajectories')
axs[0].set_xlabel('epoch')
axs[0].set_ylabel('mean-squared error')
axs[0].legend(frameon=False)
panel_label(axs[0], '(a)')
for j, cid in enumerate(['I1','I2','I3']):
    rows = [r for r in gen if r['case_id']==cid]
    t = np.array([float(r['t']) for r in rows])
    exact = np.array([float(r['x_exact']) for r in rows])
    pred = np.array([float(r['x_network']) for r in rows])
    axs[1].plot(t, exact, lw=1.15, label='exact' if j==0 else None)
    axs[1].plot(t, pred, '--', lw=1.0, label='network' if j==0 else None)
axs[1].set_xlabel('time')
axs[1].set_ylabel('displacement')
axs[1].legend(frameon=False)
panel_label(axs[1], '(b)')
save(fig, 'oscillator_learning')

# Figure: physical validation split + leakage comparison
fig, axs = plt.subplots(1, 2, figsize=(7.05, 2.45))
train = [r for r in split if r['split']=='train']
val = [r for r in split if r['split']!='train']
axs[0].scatter([float(r['omega0']) for r in train], [float(r['zeta']) for r in train], s=13, alpha=.65, label='training systems')
axs[0].scatter([float(r['omega0']) for r in val], [float(r['zeta']) for r in val], s=20, marker='x', label='held-out systems')
axs[0].set_xlabel(r'natural frequency $\omega_0$')
axs[0].set_ylabel(r'damping ratio $\zeta$')
legend_handles, legend_labels = axs[0].get_legend_handles_labels()
panel_label(axs[0], '(a)')
labels = ['random-point\nvalidation','same model on\nunseen systems','trajectory-split\nunseen systems']
vals = [summary['random_point_validation_mse'], summary['random_split_unseen_trajectory_mse'], summary['trajectory_split_unseen_trajectory_mse']]
axs[1].bar(np.arange(3), vals)
axs[1].set_yscale('log')
axs[1].set_ylabel('mean-squared error')
axs[1].set_xticks(np.arange(3), labels)
axs[1].tick_params(axis='x', labelsize=6.8)
panel_label(axs[1], '(b)')
# Move Figure 3's legend directly under panel (a).
axs[0].legend(legend_handles, legend_labels, frameon=False, ncol=2, fontsize=6.8,
              loc='upper center', bbox_to_anchor=(0.58, -0.28),
              columnspacing=3.0, handlelength=1.6, borderaxespad=0.0)
fig.subplots_adjust(bottom=0.31, wspace=0.30)
# Save explicitly here so tight_layout does not pull the external legend back into the axes.
fig.savefig(FIG/'validation_protocol.pdf', bbox_inches='tight')
fig.savefig(FIG/'validation_protocol.png', dpi=240, bbox_inches='tight')
fig.savefig(PLOTS/'validation_protocol.png', dpi=240, bbox_inches='tight')
plt.close(fig)

# Figure: interpolation versus extrapolation
fig, axs = plt.subplots(1, 2, figsize=(7.05, 2.75))
for cid, label in [('I2','inside training range'),('E2','outside training range')]:
    rows = [r for r in gen if r['case_id']==cid]
    t = np.array([float(r['t']) for r in rows])
    exact = np.array([float(r['x_exact']) for r in rows])
    pred = np.array([float(r['x_network']) for r in rows])
    axs[0].plot(t, exact, lw=1.15, label=f'exact: {label}')
    axs[0].plot(t, pred, '--', lw=1.0, label=f'network: {label}')
axs[0].set_xlabel('time')
axs[0].set_ylabel('displacement')
gen_handles, _ = axs[0].get_legend_handles_labels()
gen_labels = ['exact: inside\ntraining range', 'network: inside\ntraining range',
              'exact: outside\ntraining range', 'network: outside\ntraining range']
panel_label(axs[0], '(a)')
case_labels = [r['case_id'] for r in gen_sum]
case_errors = [float(r['relative_l2_error']) for r in gen_sum]
axs[1].bar(np.arange(len(case_labels)), case_errors)
axs[1].axvline(2.5, color='0.5', lw=.8, ls=':')
axs[1].set_yscale('log')
axs[1].set_xticks(np.arange(len(case_labels)), case_labels)
axs[1].set_xlabel('I: interpolation; E: extrapolation')
axs[1].set_ylabel(r'relative $L^2$ error')
panel_label(axs[1], '(b)')
# Put the panel-(a) legend directly under panel (a).
axs[0].legend(gen_handles, gen_labels, frameon=False, fontsize=5.8, ncol=2,
              loc='upper center', bbox_to_anchor=(0.53, -0.20),
              columnspacing=3.0, handlelength=2.0, borderaxespad=0.0)
fig.subplots_adjust(bottom=0.34, wspace=0.24)
fig.savefig(FIG/'generalization_regimes.pdf', bbox_inches='tight')
fig.savefig(FIG/'generalization_regimes.png', dpi=240, bbox_inches='tight')
fig.savefig(PLOTS/'generalization_regimes.png', dpi=240, bbox_inches='tight')
plt.close(fig)

# Figure: neural vs RBF and solver timing
rbf_interp = np.mean([float(r['relative_l2_error']) for r in rbf_sum if r['regime']=='interpolation'])
rbf_extra = np.mean([float(r['relative_l2_error']) for r in rbf_sum if r['regime']=='extrapolation'])
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.45))
x = np.arange(2); width=.34
axs[0].bar(x-width/2, [summary['mean_interpolation_relative_l2'],summary['mean_extrapolation_relative_l2']], width, label='neural surrogate')
axs[0].bar(x+width/2, [rbf_interp,rbf_extra], width, label='local RBF')
axs[0].set_yscale('log')
axs[0].set_xticks(x, ['interpolation','extrapolation'])
axs[0].set_ylabel(r'mean relative $L^2$ error')
axs[0].legend(frameon=False, fontsize=7)
panel_label(axs[0], '(a)')
axs[1].bar(np.arange(2), [summary['direct_solver_seconds_per_trajectory']*1e3, summary['network_seconds_per_trajectory']*1e3])
axs[1].set_yscale('log')
axs[1].set_xticks([0,1], ['direct ODE\nsolver','neural\nevaluation'])
axs[1].set_ylabel('milliseconds per trajectory')
panel_label(axs[1], '(b)')
save(fig, 'baseline_comparison')

# Figure: inverse identification. Load the frozen network; do not retrain.
class MLP(nn.Module):
    def __init__(self, width=48, depth=3):
        super().__init__()
        layers=[nn.Linear(3,width),nn.Tanh()]
        for _ in range(depth-1): layers += [nn.Linear(width,width),nn.Tanh()]
        layers += [nn.Linear(width,1)]
        self.net=nn.Sequential(*layers)
    def forward(self,x):
        lo=torch.tensor([0.0,0.8,0.03],dtype=x.dtype,device=x.device)
        hi=torch.tensor([10.0,2.0,0.35],dtype=x.dtype,device=x.device)
        return self.net(2.0*(x-lo)/(hi-lo)-1.0)

def oscillator(t, omega0, zeta):
    t=np.asarray(t,dtype=float)
    wd=omega0*np.sqrt(max(1-zeta*zeta,1e-12))
    return np.exp(-zeta*omega0*t)*(np.cos(wd*t)+zeta/np.sqrt(max(1-zeta*zeta,1e-12))*np.sin(wd*t))

model=MLP(); state=torch.load(DATA/'oscillator_surrogate.pt', map_location='cpu', weights_only=True); model.load_state_dict(state); model.eval()
fine=np.linspace(0,8,400).astype('float32')
wh=float(trace[-1]['omega0_estimate']); zh=float(trace[-1]['zeta_estimate'])
with torch.no_grad():
    inp=torch.from_numpy(np.c_[fine,np.full_like(fine,wh),np.full_like(fine,zh)])
    fit=model(inp).squeeze().numpy()
tobs=np.array([float(r['t']) for r in inv_obs]); noisy=np.array([float(r['x_noisy']) for r in inv_obs])
fig, axs = plt.subplots(1, 2, figsize=(7.05, 2.45))
axs[0].scatter(tobs,noisy,s=11,label='noisy observations',zorder=3)
axs[0].plot(fine,oscillator(fine,summary['true_omega0'],summary['true_zeta']),lw=1.2,label='true trajectory')
axs[0].plot(fine,fit,'--',lw=1.1,label='surrogate fit')
axs[0].set_xlabel('time'); axs[0].set_ylabel('displacement'); axs[0].legend(frameon=False,fontsize=6.8)
panel_label(axs[0], '(a)')
axs[1].plot([int(r['step']) for r in trace],[float(r['omega0_estimate']) for r in trace],label=r'$\omega_0$ estimate')
axs[1].plot([int(r['step']) for r in trace],[float(r['zeta_estimate']) for r in trace],label=r'$\zeta$ estimate')
axs[1].axhline(summary['true_omega0'],lw=.8,ls=':',color='0.4'); axs[1].axhline(summary['true_zeta'],lw=.8,ls=':',color='0.4')
axs[1].set_xlabel('inverse-optimization step'); axs[1].set_ylabel('parameter value'); axs[1].legend(frameon=False,fontsize=6.8)
panel_label(axs[1], '(b)')
save(fig, 'inverse_identification')
